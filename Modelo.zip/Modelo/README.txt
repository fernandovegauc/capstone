*Para correr el modelo se debe tener instalado Python3, Pandas y Gurobi.
*el modelo grande es el archivo modelo_gurobi.py
*los conjuntos y subconjuntos están en el archivo conjuntos_new.py
*Se entrega un script de un modelo reducido con datos ficticios, esto se encuentra en modelo_reducido.py
** Es de vital importnacia tener todos los archivos csv y scripts adjuntos en el mismo directorio para
un correcto funcionamiento del modelo. 